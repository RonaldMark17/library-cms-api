<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background: linear-gradient(135deg, #2563eb 0%, #1e40af 100%); color: white; padding: 30px; text-align: center; border-radius: 8px 8px 0 0; }
        .content { background: #f8fafc; padding: 30px; border-radius: 0 0 8px 8px; }
        .button { display: inline-block; padding: 14px 32px; background: #2563eb; color: white; text-decoration: none; border-radius: 6px; margin: 20px 0; font-weight: bold; }
        .footer { text-align: center; margin-top: 20px; color: #64748b; font-size: 14px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>📚 Library CMS</h1>
            <p>Verify Your Subscription</p>
        </div>
        <div class="content">
            <h2>Welcome!</h2>
            <p>Thank you for subscribing to our library announcements.</p>
            <p>Please verify your email address to start receiving updates:</p>
            <p style="text-align: center;">
                <a href="<?php echo e($verificationUrl); ?>" class="button">Verify Email Address</a>
            </p>
            <p>Or copy and paste this link into your browser:</p>
            <p style="background: white; padding: 12px; border-radius: 6px; word-break: break-all;">
                <?php echo e($verificationUrl); ?>

            </p>
            <p>This link will expire in 24 hours.</p>
        </div>
        <div class="footer">
            <p>If you didn't subscribe to our library, please ignore this email.</p>
            <p>&copy; 2024 Library CMS. All rights reserved.</p>
        </div>
    </div>
</body>
</html><?php /**PATH C:\Users\ronal\library-cms-api\resources\views\emails\subscription-verify.blade.php ENDPATH**/ ?>